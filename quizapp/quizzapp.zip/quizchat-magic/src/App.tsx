import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { PDFProvider } from '@/contexts/PDFContext';
import { LearningProvider } from '@/contexts/LearningContext';
import { Toaster } from '@/components/ui/toaster';
import AppRoutes from '@/routes';

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <PDFProvider>
          <LearningProvider>
            <AppRoutes />
            <Toaster />
          </LearningProvider>
        </PDFProvider>
      </AuthProvider>
    </Router>
  );
};

export default App;
